/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hakibar <hakibar@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/18 03:39:29 by hakibar           #+#    #+#             */
/*   Updated: 2026/03/18 03:39:29 by hakibar          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>

#include "Animal.hpp"
#include "Cat.hpp"
#include "Dog.hpp"

int	main(void)
{
	std::cout << "=== Animal array test ===" << std::endl;
	Animal	*animals[6];

	for (int i = 0; i < 3; ++i)
		animals[i] = new Dog();

	for (int i = 3; i < 6; ++i)
		animals[i] = new Cat();

	for (int i = 0; i < 6; ++i)
		animals[i]->makeSound();

	for (int i = 0; i < 6; ++i)
		delete animals[i];

	std::cout << std::endl;

	std::cout << "=== Deep copy test (Dog) ===" << std::endl;
	Dog	originalDog;

	originalDog.setIdea(0, "Chase the mailman");
	Dog copyDog(originalDog);
	originalDog.setIdea(0, "Sleep all day");

	std::cout << "Original dog idea[0]: " << originalDog.getIdea(0) << std::endl;
	std::cout << "Copy dog idea[0]: " << copyDog.getIdea(0) << std::endl;

	std::cout << std::endl;

	std::cout << "=== Deep copy test (Cat) ===" << std::endl;
	Cat	originalCat;
	Cat	copyCat;

	originalCat.setIdea(1, "Steal fish");
	copyCat = originalCat;
	originalCat.setIdea(1, "Ignore humans");

	std::cout << "Original cat idea[1]: " << originalCat.getIdea(1) << std::endl;
	std::cout << "Copy cat idea[1]: " << copyCat.getIdea(1) << std::endl;
	return (0);
}
