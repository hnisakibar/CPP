/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Cat.cpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hakibar <hakibar@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/18 03:39:29 by hakibar           #+#    #+#             */
/*   Updated: 2026/03/18 03:39:29 by hakibar          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Cat.hpp"

#include <iostream>

Cat::Cat(void) : Animal(), _brain(new Brain())
{
	type = "Cat";
	std::cout << "Cat default constructor called" << '\n';
}

Cat::Cat(const Cat &other) : Animal(other), _brain(new Brain())
{
	std::cout << "Cat copy constructor called" << '\n';
	*_brain = *(other._brain);
}

Cat	&Cat::operator=(const Cat &other)
{
	std::cout << "Cat copy assignment operator called" << '\n';
	if (this != &other)
	{
		Animal::operator=(other);
		*_brain = *(other._brain);
	}
	return (*this);
}

Cat::~Cat(void)
{
	std::cout << "Cat destructor called" << '\n';
	delete _brain;
}

void	Cat::makeSound(void) const
{
	std::cout << "Meow meow!" << '\n';
}

void	Cat::setIdea(int index, const std::string &idea)
{
	_brain->setIdea(index, idea);
}

std::string const	&Cat::getIdea(int index) const
{
	return (_brain->getIdea(index));
}
