/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Brain.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hakibar <hakibar@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/18 03:39:29 by hakibar           #+#    #+#             */
/*   Updated: 2026/03/18 03:39:29 by hakibar          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Brain.hpp"

#include <iostream>

namespace
{
	std::string const	g_emptyIdea = "";
}

Brain::Brain(void)
{
	std::cout << "Brain default constructor called" << '\n';
}

Brain::Brain(const Brain &other)
{
	std::cout << "Brain copy constructor called" << '\n';
	*this = other;
}

Brain	&Brain::operator=(const Brain &other)
{
	std::cout << "Brain copy assignment operator called" << '\n';
	if (this != &other)
	{
		for (int i = 0; i < 100; ++i)
			_ideas[i] = other._ideas[i];
	}
	return (*this);
}

Brain::~Brain(void)
{
	std::cout << "Brain destructor called" << '\n';
}

void	Brain::setIdea(int index, const std::string &idea)
{
	if (index < 0 || index >= 100)
		return ;
	_ideas[index] = idea;
}

std::string const	&Brain::getIdea(int index) const
{
	if (index < 0 || index >= 100)
		return (g_emptyIdea);
	return (_ideas[index]);
}
