/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Dog.cpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hakibar <hakibar@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/18 03:39:29 by hakibar           #+#    #+#             */
/*   Updated: 2026/03/18 03:39:29 by hakibar          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Dog.hpp"

#include <iostream>

Dog::Dog(void) : Animal(), _brain(new Brain())
{
	type = "Dog";
	std::cout << "Dog default constructor called" << '\n';
}

Dog::Dog(const Dog &other) : Animal(other), _brain(new Brain())
{
	std::cout << "Dog copy constructor called" << '\n';
	*_brain = *(other._brain);
}

Dog	&Dog::operator=(const Dog &other)
{
	std::cout << "Dog copy assignment operator called" << '\n';
	if (this != &other)
	{
		Animal::operator=(other);
		*_brain = *(other._brain);
	}
	return (*this);
}

Dog::~Dog(void)
{
	std::cout << "Dog destructor called" << '\n';
	delete _brain;
}

void	Dog::makeSound(void) const
{
	std::cout << "Woof woof!" << '\n';
}

void	Dog::setIdea(int index, const std::string &idea)
{
	_brain->setIdea(index, idea);
}

std::string const	&Dog::getIdea(int index) const
{
	return (_brain->getIdea(index));
}
