/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Animal.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hakibar <hakibar@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/18 03:39:29 by hakibar           #+#    #+#             */
/*   Updated: 2026/03/18 03:39:29 by hakibar          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ANIMAL_HPP
# define ANIMAL_HPP

# include <string>

class Animal
{
public:
	Animal(void);
	Animal(const Animal &other);
	Animal	&operator=(const Animal &other);
	virtual ~Animal(void);

	std::string const	&getType(void) const;
	virtual void		makeSound(void) const;

protected:
	std::string	type;
};

#endif
