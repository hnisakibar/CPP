/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hakibar <hakibar@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/18 03:39:29 by hakibar           #+#    #+#             */
/*   Updated: 2026/03/18 03:39:29 by hakibar          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>

#include "Animal.hpp"
#include "Cat.hpp"
#include "Dog.hpp"

int	main(void)
{
	std::cout << "=== Abstract animal polymorphism ===" << std::endl;

	Animal const	*j = new Dog();

	Animal const	*i = new Cat();

	std::cout << j->getType() << std::endl;
	std::cout << i->getType() << std::endl;

	j->makeSound();
	i->makeSound();

	delete j;
	delete i;

	std::cout << std::endl;
	std::cout << "=== Deep copy quick check ===" << std::endl;

	Dog	one;

	Dog	two(one);

	one.setIdea(0, "Bone");
	two.setIdea(0, "Park");

	std::cout << "Dog one idea[0]: " << one.getIdea(0) << std::endl;
	std::cout << "Dog two idea[0]: " << two.getIdea(0) << std::endl;

	return (0);
}
